<template>
    <div class="page">
        <p>
            Oops, không thể tìm thấy trang. Trở về
            <router-link to="/">trang chủ.</router-link>
        </p>
    </div>
</template>