<template>
    <nav class="navbar navbar-expand-lg navbar-dark custom-navbar">
        <div class="container">
            <a href="/" class="navbar-brand">
                <i class="fas fa-book-alt"></i>
                ỨNG DỤNG QUẢN LÝ THƯ VIỆN
                <i class="fas fa-book-reader" style="margin-left: 10px;"></i>
            </a>
        </div>
    </nav>
</template>

<style scoped>
.custom-navbar {
    background: linear-gradient(90deg, #3b5998, #8b9dc3);
    padding: 1rem 1.5rem;
    box-shadow: 0px 4px 8px rgba(74, 36, 36, 0.2);
}
.navbar-brand {
    font-size: 1.5rem;
    font-weight: bold;
    display: flex;
    align-items: center;
    margin-right: 50px;
}
.navbar-brand i {
    margin-right: 0.5rem;
    font-size: 1.25rem;
}
.nav-link {
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    margin-right: 20px;
}
.nav-link i {
    font-size: 1.2rem;
    color: #ffffff;
}
</style>